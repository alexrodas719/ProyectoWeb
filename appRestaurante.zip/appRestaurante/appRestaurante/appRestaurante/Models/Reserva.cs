﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace appRestaurante.Models
{
    public class Reserva
    {
        [Key,DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdReserva { get; set; }
        [Required]
        public DateTime FechaHora{ get; set; }
        [Required,StringLength(30)] //reservado sin pago/reservado y pagado/cancelada
        public String Estado{ get; set; }

        public int IdCliente { get; set; }
        public Cliente Cliente { get; set; }

        public int IdMesa {  get; set; }
        public Mesa Mesa { get; set; }

        public ICollection<Orden> Ordenes { get; set; }
    }
    /*
       Cliente y Reserva: Un Cliente puede realizar muchas **Reserva**s, pero 
            cada Reserva pertenece a un solo Cliente. Esta es una relación uno 
            a muchos. La tabla Reserva debe tener una clave foránea (ClienteId).

       Mesa y Reserva: Una Mesa puede tener muchas **Reserva**s a lo largo del tiempo, 
            pero en un momento dado, una Reserva es para una sola Mesa. 
            Esta es una relación uno a muchos. La tabla Reserva debe 
            tener una clave foránea (MesaId).

       Reserva y Orden: Una Reserva puede tener una o varias **Orden**es 
           (una orden para la comida, otra para las bebidas, etc., aunque es 
           más común que una reserva tenga una sola orden principal). En este
           caso, consideraremos una relación uno a uno si una reserva tiene una
           única orden o uno a muchos si una reserva puede generar varias órdenes
           a lo largo del tiempo. Siendo esta última la más flexible, te sugiero 
           una relación uno a muchos donde la tabla Orden tenga una clave foránea(ReservaId).
    
       Usuario y Cliente / Rol: Un Usuario puede tener un solo Rol 
        (ej. "Cliente", "Administrador"). Por otro lado, un Usuario de tipo cliente
        se corresponde con una única entrada en la tabla Cliente. Esto establece una 
        relación uno a uno entre Usuario y Cliente, y una relación muchos a uno 
        entre Usuario y Rol.
     */
}
