﻿namespace appRestaurante.Models
{
    public class Orden
    {
        public int OrdenId { get; set; }
        public DateTime FechaHoraOrden { get; set; }
        public decimal Total { get; set; }

      
        public int IdReserva { get; set; }
        public Reserva Reserva { get; set; }
    }
}
