﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace appRestaurante.Models
{
    public class Cliente
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdCliente { get; set; }
        [Required, StringLength(120)]
        public String Nombre { get; set; }
        [Required, StringLength(60)]
        public String Correo { get; set; }
        [Required, StringLength(9)]
        public String Telefono { get; set; }

        public int UsuarioId { get; set; }
        public Usuario Usuario { get; set; }

        public ICollection<Reserva> Reservas { get; set; }

    }
}
