﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace appRestaurante.Models
{
    public class Mesa
    {
        [Key,DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdMesa { get; set; }
        public int Numero { get; set; }
        [Required,StringLength(20)]//Ocupada/Libre
        public string Estado { get; set; }

        public ICollection<Reserva> Reservas { get; set; }
    }
}
