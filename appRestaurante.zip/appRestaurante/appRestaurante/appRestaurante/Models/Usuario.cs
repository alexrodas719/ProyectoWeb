﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace appRestaurante.Models
{
    public class Usuario
    {
        [Key,DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Idusuario { get; set; }

        [StringLength(12),Required]
        public String Nombre{ get; set; }

        [StringLength(12), Required]
        public String Correo{ get; set; }

        [StringLength(12), Required]
        public String Contrasena{ get; set; }

        public int RolId { get; set; }
        public Rol Rol { get; set; }

        // Relación uno a uno con Cliente
        public Cliente Cliente { get; set; }

    }
}
