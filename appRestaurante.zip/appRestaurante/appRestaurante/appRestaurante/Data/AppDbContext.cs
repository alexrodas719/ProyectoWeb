﻿using Microsoft.EntityFrameworkCore;
using appRestaurante.Models;

namespace appRestaurante.Data
{
    public class AppDbContext: DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) 
        {

        }
        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Cliente> Clientes { get; set; }
        public DbSet<Mesa> Mesas{ get; set; }
        public DbSet<Reserva> Reservas{ get; set; }
        public DbSet<Rol> Roles{ get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Relación uno a uno entre Usuario y Cliente
            modelBuilder.Entity<Usuario>()
                .HasOne(u => u.Cliente)
                .WithOne(c => c.Usuario)
                .HasForeignKey<Cliente>(c => c.UsuarioId);

            // Relación muchos a uno entre Usuario y Rol
            modelBuilder.Entity<Usuario>()
                .HasOne(u => u.Rol)
                .WithMany(r => r.Usuarios)
                .HasForeignKey(u => u.RolId);

            // Relación uno a muchos entre Cliente y Reserva
            modelBuilder.Entity<Cliente>()
                .HasMany(c => c.Reservas)
                .WithOne(r => r.Cliente)
                .HasForeignKey(r => r.IdCliente);

            // Relación uno a muchos entre Mesa y Reserva
            modelBuilder.Entity<Mesa>()
                .HasMany(m => m.Reservas)
                .WithOne(r => r.Mesa)
                .HasForeignKey(r => r.IdMesa);

            // Relación uno a muchos entre Reserva y Orden
            modelBuilder.Entity<Reserva>()
                .HasMany(r => r.Ordenes)
                .WithOne(o => o.Reserva)
                .HasForeignKey(o => o.IdReserva);

            base.OnModelCreating(modelBuilder);
        }
    }

}
