﻿namespace appRestaurante.Controllers
{
    public class ClienteController
    {

    }
}
